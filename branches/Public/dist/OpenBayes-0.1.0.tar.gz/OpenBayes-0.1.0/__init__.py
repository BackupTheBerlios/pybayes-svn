#Python __init__.py file
#setup.py
__all__ = ['bayesnet','distributions','inference','potentials','table']

# this will only import the class names defined in the __all__ parameter of each
# file :
from bayesnet import *
from inference import *
from distributions import *
from potentials import *
from table import *


# comment this out if you are using OpenBayes into another package
# and want this to appear
#print 'Welcome to OpenBayes!!!'
